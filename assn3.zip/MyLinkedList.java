import java.util.*;
class Node<X>{
    //the data fields
    public X data;
    public Node<X> next;
}

public class MyLinkedList<X>implements Iterable<X>{
    //the data fields
    public Node<X> head;
    public Node<X> tail;
    protected int size;

    public MyLinkedList(){
        head=null;
        tail=null;
        size=0;
    }

    public boolean isEmpty(){
        return head==null;
    }

    public void insertFront(X item){
        if(head==null){//if the list is initially empty then the head and tail of the list will start pointing to the first node introduced
            Node<X> new_node=new Node<X>();
            new_node.data=item;
            new_node.next=null;
            head=new_node;
            tail=new_node;
            size++;
        }
        else{//for a list that was not initially empty we just revise the value of the head pointer
            Node<X> new_node=new Node<X>();
            new_node.data=item;
            new_node.next=head;
            head=new_node;
            size++;
        }
    }

    public void insertRear(X item){
        if(head==null){
          Node<X> new_node=new Node<X>();
            new_node.data=item;
            new_node.next=null;
            head=new_node;
            tail=new_node;
            tail.next=null;
            size++;  
        }
        else{
            Node<X> new_node=new Node<X>();
            new_node.data=item;
            new_node.next=null;//now attaching the new node at the end of the list by first making the next of the node at tail point to this node and later by making this the tail (and of course its next points to null)
            tail.next=new_node;
            tail=new_node;
            size++;
        }
    }

    public int getSize(){
        return size;
    }

    public X get(int i){
        try{
            Node<X>current=this.head;
            for(int j=0;j<i;j++){
                current=current.next;
            }
            return current.data;
        }
        catch(java.lang.NullPointerException e){
            return null;
        }
    }

    public void deleteFront(){
        if(size==1){
            head.next=null;
            head=null;
            tail=null;
        }
        else{
            Node<X> temp_next=head.next;//is the temporary variable that stores the pointer to the second element of the list
            head.next=null;
            head=temp_next;
        }
    }

    public void deleteRear(){
        if(size==1){
            head.next=null;
            head=null;
            tail=null;
        }
        else{
            Node<X> curr=head;
            int i=0;
            while(i<size-2){
                curr=curr.next;
                i++;
            }
            curr.next=null;
            tail=curr;
        }
    }

    public void appendAtRear(MyLinkedList<X> l_list){
        this.tail.next=l_list.head;//making the next pointer of the tail node of the current linked list point to the head of the new linked list
        this.tail=l_list.tail;//making the tail of the entire arrangement equal to the tail of the rear part of the second linked list
    }


    //tells whether a given data element is present in the linked list or not
    public boolean isPresent(X item){
        Node<X> current=head;
        while(current!=null){
            if(current.data.equals(item))return true;//checking if the data element present in the current node is the same as the given one. If yes return true
            current=current.next;
        }
        return false;//if we reach the end of the linked list without finding the required data element, we return false
    }

    //if a particular string is present in the linked list, then it returns the node containing it. Returns null if it doesn't
    public X getItem(X item){//returns pointer to the node present inside the linked list containing the given data item.If no such pointer exists then it returns null  
        Node<X> current=head;
        while(current!=null){
            if(current.data.equals(item))return current.data;//checking if the data element present in the current node is the same as the given one. If yes return the current node's data object
            current=current.next;
        }
        return null;//if we reach the end of the linked list without finding the required data element, we return null
    }

    public Iterator<X> iterator(){
        return new LinkedListIterator();
    }

    class LinkedListIterator implements Iterator<X>{
        //the data field
        Node<X> current=MyLinkedList.this.head;
        public LinkedListIterator(){
            current=MyLinkedList.this.head;
        }
        public boolean hasNext(){
            return current!=null;
        }

        public X next(){
            X value=current.data;
            current=current.next;
            return value;
        }

        public void remove(){
            throw new java.lang.UnsupportedOperationException();
        }
}

}

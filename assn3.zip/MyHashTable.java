public class MyHashTable{

	public MyLinkedList<WordEntry>[] pos;//the array of WordEntry linked lists which holds the WordEntry corresponding to diffrent strings.
	//the array of linked lists lets us do chaining
	public MyHashTable(){
		pos= (MyLinkedList<WordEntry>[])new MyLinkedList[10000000];
		for(int i=0;i<10000000;i++){//the hash code would be the product of the ascii values of the digits divided by 10000000 i.e. 7 zeroes
			pos[i]=new MyLinkedList<WordEntry>();//each entry initialized to a new linked list
		}
	}

	private int getHashIndex(String str){//the hashcode is that for a string the value generated is the ascii value of its first character
		int value=1;//stores the value of the product of the ascii values of the characters
		if(str.equals(" "))return 27;//the hash code of " " is arbitrarily assignes equal to twenty seven
		for(int i=0;i<str.length();i++){
			value=value*((int)str.charAt(i)-95);//the ascii code of a=1,b=2,c=3 and so on
		}
		value=Math.abs(value%10000000);
		//System.out.println("the value of the hash code corresponding to string "+str+" is "+value);
		return value;
	}

	public void addPositionsForWord(WordEntry w){//adds new positions corresponding to the WOrdEntry "w"
		String str=w.word;
		int val=getHashIndex(str);//get the value of the hash code of the string inside the WordEntry 'w'
		MyLinkedList<WordEntry>relevant_list=pos[val];
		if(!relevant_list.isPresent(w)){//if an entry corresponding to the same string is not present then add a new WordEntry
			relevant_list.insertFront(w);
		}
		else{//if the entry is already there then
			MyLinkedList<Position> all_positions=w.getAllPositionsForThisWord();
			WordEntry in_the_list=relevant_list.getItem(w);//returns the node corresponding to the same string but present in the hash table
			in_the_list.addPositions(all_positions);//adds all the relevant positions to the entry already present in the hash table  
		}
	}

	public WordEntry find(String str){//for a query string finds the relevant WordEntry present in the hash table and returns a pointer to that
		int hash_value=getHashIndex(str);//getting the hash value corresponding to that string
		WordEntry temp_entry=new WordEntry(str);//making a temporary WordEntry to facilitate the search with
		if(pos[hash_value]==null)return null;//returning null if the linked list at this hash code is null
		MyLinkedList<WordEntry> relevant_list=pos[hash_value];
		if(!relevant_list.isPresent(temp_entry)) return null;//we return null if the query string is not present in the hashtable 
		else{
			WordEntry in_the_list=relevant_list.getItem(temp_entry);
			return in_the_list;//returns the word entry corresponding to that string present inside the hashtable
		}
	}

}
/*The Myset class*/
public  class MySet<X>{

	/*the data field of the Myset class*/
	public MyLinkedList<X> Mset;

	public MySet (){
		Mset=new MyLinkedList<X>();
	}



	public Boolean IsEmpty(){
		return Mset.isEmpty();
	}

	public Boolean IsMember(X o){
		Node<X> current=Mset.head;
		while(current!=null){
			if(current.data.equals(o))return true;
			current=current.next;
		}
		return false;
	}

	public void Insert(X o){
		Mset.insertFront(o);//insert at start increases the size of the list by itself.No need to increase size here as well.
	}

	public MySet Union(MySet<X> a){
		MySet<X> union=new MySet<X>();
		Node<X> current=a.Mset.head;
		while(current!=null){
			union.Insert(current.data);	//transfer all elements of the linked list a into the new Union linkedList
			current=current.next;
		}
		current=this.Mset.head;
		while(current!=null){
			if(!(union.IsMember(current.data))){
			union.Insert(current.data); //transfer all elements of the linked list self into the new Union linkedList
			}
			current=current.next; 
		}

		return union;
	}

	public MySet Intersection(MySet<X> a){
		MySet<X> intersection=new MySet<X>();
		Node<X> current=this.Mset.head;
		while(current!=null){
			if(a.IsMember(current.data)){
			intersection.Insert(current.data);
		}
		current=current.next;
		}
		
		return intersection;   //time complexity=N^2(N=no of elements in the set.Optimize later if very slow)
	}


}

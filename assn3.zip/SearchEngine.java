import java.util.*;
public class SearchEngine{

	InvertedPageIndex word_locations;//the Inverted Page index that contains strings and their positions in different web pages

	public SearchEngine(){
		word_locations=new InvertedPageIndex();//initialized to an empty InvertedPageIndex
	}

	public void performAction(String actionMessage){
		int i=0,j=0;
		//No problem till this point in the code
		while(!actionMessage.substring(i,i+1).equals(" "))i++;
		String command=actionMessage.substring(0,i);
		//adding a new page to the inverted index
		if(command.equals("addPage")){
			String page_name=actionMessage.substring(i+1,actionMessage.length());
			PageEntry new_page=new PageEntry(page_name);
			word_locations.addPage(new_page);
		}

		//which pages contain which word
		else if(command.equals("queryFindPagesWhichContainWord")){
			String word_name=actionMessage.substring(i+1,actionMessage.length());
			MySet<PageEntry> relevant_pages=word_locations.getPagesWhichContainWord(word_name.toLowerCase());
			if(relevant_pages==null||relevant_pages.IsEmpty()){
				System.out.println("No webpage contains word "+word_name);
			}//if there are no relevant pages then
			else{
			Node<PageEntry> current=relevant_pages.Mset.head;
			String output_string="";
			for(PageEntry p:relevant_pages.Mset){
				output_string=output_string+p.page_name+", ";
			}
			output_string=output_string.substring(0,output_string.length()-2);
			System.out.println(output_string);
		}
		}

		//positions of words in a page
		else if(command.equals("queryFindPositionsOfWordInAPage")){
			while(!actionMessage.substring(i+j+1,i+j+2).equals(" "))j++;
			String relevant_word=actionMessage.substring(i+1,i+j+1);// the word to be found
			String doc_name=actionMessage.substring(i+j+2,actionMessage.length());//the name of the page
			if(!word_locations.page_names.isPresent(doc_name)) System.out.println("No webpage "+doc_name+" found.");
			else{
			WordEntry temp_word_entry=new WordEntry(relevant_word.toLowerCase());
			PageEntry temp_entry=new PageEntry(doc_name);//creating a temporary page entry corresponding to the page name
			MySet<PageEntry> relevant_pages_corresponding_to_word=word_locations.getPagesWhichContainWord(relevant_word);
			if(relevant_pages_corresponding_to_word==null){
				System.out.println("Webpage "+doc_name+" does not contain word "+relevant_word);
			}
			else{    
			if(!relevant_pages_corresponding_to_word.Mset.isPresent(temp_entry)){
				System.out.println("Webpage "+doc_name+" does not contain word "+relevant_word);
			}
			else{
				PageEntry real_relevant_page=relevant_pages_corresponding_to_word.Mset.getItem(temp_entry);//contains pointer to the relevant page entry inside the linked list of MySet
				WordEntry the_word_in_that_page=real_relevant_page.p.entries.getItem(temp_word_entry);
				Node<Position> current=the_word_in_that_page.pos.head;//points to the head of the positions linked list inside the word entry
				String output_string="";
				while(current!=null){
					output_string=output_string+Integer.toString(current.data.getWordIndex())+", ";
					current=current.next;
				}
				output_string=output_string.substring(0,output_string.length()-2);
				System.out.println(output_string);
			}
		}
		}
	}
	}
}
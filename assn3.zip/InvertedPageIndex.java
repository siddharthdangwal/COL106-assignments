public class InvertedPageIndex{

	public MyHashTable words_and_positions;//the hash table which stores all the
	public MyLinkedList<String> page_names; 

	public InvertedPageIndex(){
		words_and_positions=new MyHashTable();
		page_names=new MyLinkedList<String>();
	}

	public void addPage(PageEntry p){
		PageIndex p_page_index=p.getPageIndex();//p_page_index contains the linked list of all words and their positions in the PageEntry "p"
		String p_name=p.page_name;//the name of the webpage
		page_names.insertFront(p_name);//inserting the name in the linked list storing the names of all the pages added
		MyLinkedList<WordEntry> p_page_index_word_entries=p_page_index.getWordEntries();//p-page_index_word_entries is the linked list that contains all words and their positions
		Node<WordEntry> current=p_page_index_word_entries.head;
		while(current!=null){
			words_and_positions.addPositionsForWord(current.data);//adding the word entries present in the page entry of that webpage into the inverted index.
			current=current.next;
		}
	}

	public MySet<PageEntry> getPagesWhichContainWord(String str){
		MySet<PageEntry> relevant_pages=new MySet<PageEntry>();//the MySet that contains all the relevant pages to the query string
		WordEntry in_the_hash_table=words_and_positions.find(str);//returns a pointer to the WordEntry corresponding to this string present inside the hashtable
		if(in_the_hash_table==null)return null;//if this is null means that this word does not exist in the hash table
		
		else{
		MyLinkedList<Position> all_the_positions=in_the_hash_table.getAllPositionsForThisWord();//stores the postions of that word entry
		for(Position position:all_the_positions){
			PageEntry p=position.getPageEntry();
			if(!relevant_pages.IsMember(p)){
			relevant_pages.Insert(p);//stores the PageEntries corresponding the locations of a WordEntry
			}
			
		}
		return relevant_pages;
	}
	} 
}
//no problem with page entry
import java.util.*;
import java.io.*;
public class PageEntry{

	public PageIndex p;//the page index corresponding to this web page
	private Scanner scn;//the scanner which will read all the words present in the file whose name is entered
	public String page_name;

	public PageEntry(String pageName){
		page_name=pageName;
		p=new PageIndex();
		try{
		File file =new File(pageName);
		scn=new Scanner(file);//the scanner 'scn' reads input from this file now
		int i=0;//the counter which keeps count of the position
		String[] punctuation={"{","}","[","]","<",">","=","(",")",".",",",";","'","\"","?","#","!","-",":"};//contains the punctuaion marks which have to be replaced witha a space
		String [] special_strings={"stack","structure","application"};//contains the words whose plurals have to be taken the same as them
		String [] connectors={"a","an","the","they","these","this","for","is","are","was","of","or","and","does","will","whose"};
		while(scn.hasNextLine()){
			String word=scn.nextLine();
			//word=word.replaceAll("[^a-zA-Z0-9]+"," ");
			String [] output=word.split("\\s++|\\{|}|<|>|\\(|\\)|\\.|,|;|'|\"|\\?|#|!|-|:");
			for(int j=0;j<output.length;j++){
				if(!isPresent(output[j],connectors)){
					output[j]=output[j].toLowerCase();
				processText(output[j],i+j);
			}
			}
			i=i+output.length;
		}
	}
	catch(FileNotFoundException e){
		System.out.println("page with name "+pageName+" does not exist.");
	}

	}



	PageIndex getPageIndex(){
		return p;
	}



	private boolean isPresent(String s,String[] arr){ //returns true if the given string is present in the given arary. false otherwise
		for(int i=0;i<arr.length;i++){
			if(s.equals(arr[i])) return true;		
		}
		return false;
	}

	@Override
	public boolean equals(Object o){
		PageEntry p=(PageEntry)o;
		return(p.page_name.equals(this.page_name));
	}


	private void processText(String word,int i){
			//handling punctuations
			//String[] punctuation={"{","}","[","]","<",">","=","(",")",".",",",";","'","\"","?","#","!","-",":"};//contains the punctuaion marks which have to be replaced witha a space
			String [] special_strings={"stack","structure","application"};//contains the words whose plurals have to be taken the same as them
			//String [] connectors={"a","an","the","they","these","this","for","is","are","was","of","or","and","does","will","whose"
				if(!word.equals("")){
					//System.out.println("words corresponding to "+page_name+" are:");
					//System.out.print(word+",");
				if(isPresent(word.substring(0,word.length()-1),special_strings)){
					word=word.substring(0,word.length()-1);
					Position pos=new Position(this,i);
					p.addPositionForWord(word,pos);
					i++;
				}
				//handling the rest of the 'normal' words
				else{
					Position pos=new Position(this,i);
					p.addPositionForWord(word,pos);
					//we are reaching here
					i++;
					//System.out.println("the word is "+ word+" and the node inserted has "+p.entries.tail.data.word+" and the current size is "+p.entries.size);
				} 
			}
		} 
}
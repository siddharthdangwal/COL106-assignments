public class PageIndex{

	public MyLinkedList<WordEntry> entries;//the data field.this linked list contains all the WordEntries that are there in the document

	MyLinkedList<WordEntry> getWordEntries(){
		return entries;
	}


	void addPositionForWord(String str, Position p){
		WordEntry temp_entry=new WordEntry(str);//checking if the WordEntry corresponding to str is in the entries linked list or not
		//recieving the correct word for insertion
		if(entries.isPresent(temp_entry)){
			//System.out.println("the if condition is true");
			WordEntry real_entry=entries.getItem(temp_entry);//real entry points to the WordEntry corresponding to the particular word in the linked list
			real_entry.addPosition(p);//add this position to the real word entry
		}
		else{
			temp_entry.addPosition(p);
			//System.out.println("pre insertion the size of the linked list is "+entries.size);
			entries.insertRear(temp_entry);//if no WordEntry corresponding to the given string is present then insert the newly created WordEntry into the entries linked list
			//System.out.println("post insertion the size of the linked list is "+entries.size);
		}
	}

	public PageIndex(){
		entries=new MyLinkedList<WordEntry>();
	}


}
public class WordEntry{
	
	//the data fields
	public String word;
	public MyLinkedList<Position> pos;//the list of indices

	//the constructor
	public WordEntry(String word){
		this.word=word;
		pos=new MyLinkedList<Position>();
	}

	//add a position entry for str
	public void addPosition(Position position){
		pos.insertRear(position);
	}

	// just appending the new list at the end of the pre-existing ones
	public void addPositions(MyLinkedList<Position> positions){
		pos.appendAtRear(positions);
	}

	//returns a list of all positions for the current word
	public MyLinkedList<Position> getAllPositionsForThisWord(){
		return pos;
	}

	//
	public float getTermFrequency(){
		return (float)pos.getSize();
	}

	@Override
	public boolean equals(Object o){
		WordEntry w=(WordEntry)o;
		if(w.word.equals(this.word)) return true;
		else return false;
	}

}
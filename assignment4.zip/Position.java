public class Position{
	//the data fields
	private PageEntry p;
	private int wordIndex;//the position of the word in the page
	public int real_index;//contains the index with the helper words included

	public Position(PageEntry p,int wordIndex){
		this.p=p;
		this.wordIndex=wordIndex;
	}

	public PageEntry getPageEntry(){
		return p;
	}

	public int getWordIndex(){
		return wordIndex;
	}

	public void setRealPos(int real_position){
		real_index=real_position;
	}

	@Override
	public boolean equals(Object o){
		Position ptn=(Position)o;
		return(p.equals(ptn.getPageEntry())&&(this.wordIndex==ptn.getWordIndex()));
	}
}
//successfully compiled
class AVLNode{
	//the data fields
	public Position data;
	public int height=0;
	public AVLNode left,right;
	//the constructors
	public AVLNode(){
		data=null;
		height=0;
		left=null;
		right=null;
	}
	public AVLNode(Position pos){
		this.data=pos;
		height=0;
		left=null;
		right=null;
	}
}

public class AVLTree{
	public AVLNode root; //the root of the tree. the only data field
    private int num_nodes=0;
    private int find_iter=0;
	//th constructor
	public AVLTree(){
        num_nodes=0;
        find_iter=0;
	}

	public AVLTree(Position p){
	}

	//the find operation
	public boolean find(Position p){
		return find(p,root);
	}

	private boolean find(Position p,AVLNode node){
        if(node!=null){
            if(node.data.real_index==p.real_index){
                //System.out.println("find_iterations = "+find_iter);
                //find_iter=0;
                return true;
            }
            else if(node.data.real_index>p.real_index){
                //find_iter++;
                return find(p,node.left);
            }
            else if(node.data.real_index<p.real_index){
                //find_iter++;
                return find(p,node.right);
            }
        }
        //System.out.println("null_find_iterations = "+find_iter);
        //find_iter=0;
        return false;//return false if the end node is reached without succesfully finding the position
	}


	public void insert(Position p){
		root=insert(p,root);
	}


    //insert works fine
	private AVLNode insert(Position p, AVLNode t)
     {
         if (t == null){
             t = new AVLNode(p);
         }

         else if (p.real_index < t.data.real_index)
         {
             t.left = insert( p, t.left );
             if( height( t.left ) - height( t.right ) == 2 )
                 if( p.real_index < t.left.data.real_index)
                     t = rotate_Left_Left( t );
                 else
                     t = rotate_Left_Right( t );
         }
         else if( p.real_index> t.data.real_index)
         {
             t.right = insert( p, t.right );
             if( height( t.right ) - height( t.left ) == 2 )
                 if( p.real_index > t.right.data.real_index)
                     t = rotate_Right_Right( t );
                 else
                     t = rotate_Right_Left( t );
         }
         else
           ;  // Duplicate; do nothing
         t.height = Math.max( height( t.left ), height( t.right ) ) + 1;
         return t;
     }


     private AVLNode rotate_Left_Left(AVLNode t){
     	AVLNode t1=t.left;
     	AVLNode rightmost_tree=t.right;
     	AVLNode second_from_right=t1.right;
     	AVLNode t2=t1.left;
     	AVLNode leftmost_tree=t2.left;
     	AVLNode second_from_left=t2.right;
     	t2.left=leftmost_tree;
     	t2.right=second_from_left;
     	t.left=second_from_right;
     	t.right=rightmost_tree;
     	t1.left=t2;
     	t1.right=t;
        t.height=t2.height;
     	return t1;
     }

     private AVLNode rotate_Left_Right(AVLNode t){
     	AVLNode t1=t.left;
     	AVLNode t2=t1.right;
     	AVLNode leftmost_tree=t1.left;
     	AVLNode second_from_left=t2.left;
     	AVLNode second_from_right=t2.right;
     	AVLNode rightmost_tree=t.right;
     	t1.left=leftmost_tree;
     	t1.right=second_from_left;
     	t.left=second_from_right;
     	t.right=rightmost_tree;
     	t2.left=t1;
     	t2.right=t;
        t2.height+=1;
        t.height-=2;
        t1.height-=1;
     	return t2;
     }

     private AVLNode rotate_Right_Right(AVLNode t){
     	AVLNode t1=t.right;
     	AVLNode t2=t1.right;
     	AVLNode leftmost_tree=t.left;
     	AVLNode second_from_left=t1.left;
     	AVLNode second_from_right=t2.left;
     	AVLNode rightmost_tree=t2.right;
     	t1.right=t2;
     	t1.left=t;
     	t.left=leftmost_tree;
     	t.right=second_from_left;
        t.height=t2.height;
     	return t1;
     }

     private AVLNode rotate_Right_Left(AVLNode t){
     	AVLNode t1=t.right;
     	AVLNode t2=t1.left;
     	AVLNode leftmost_tree=t.left;
     	AVLNode second_from_left=t2.left;
     	AVLNode second_from_right=t2.right;
     	AVLNode rightmost_tree=t1.right;
     	t2.left=t;
     	t2.right=t1;
     	t.left=leftmost_tree;
     	t.right=second_from_left;
     	t1.left=second_from_right;
     	t1.right=rightmost_tree;
        t2.height+=1;
        t.height-=2;
        t1.height-=1;
     	return t2;
     }
     //no need to create a delete function for this tree.

     private int height(AVLNode t){
     	if(t==null)return -1;
     	else return t.height;
     }
}
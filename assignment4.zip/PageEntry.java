//no problem with page entry
import java.util.*;
import java.io.*;
public class PageEntry{

	public PageIndex p;//the page index corresponding to this web page
	private Scanner scn;//the scanner which will read all the words present in the file whose name is entered
	public String page_name;
	public InvertedPageIndex t_ind;//the overall inverted page index

	public PageEntry(String pageName){
		page_name=pageName;
		p=new PageIndex();
		try{
		File file =new File(pageName);
		scn=new Scanner(file);//the scanner 'scn' reads input from this file now
		int i=0;//the counter which keeps count of the position
		int real_position=0;//the counter which keeps track of the real_position in the page
		String[] punctuation={"{","}","[","]","<",">","=","(",")",".",",",";","'","\"","?","#","!","-",":"};//contains the punctuaion marks which have to be replaced witha a space
		String [] special_strings={"stack","structure","application"};//contains the words whose plurals have to be taken the same as them
		String [] connectors={"a","an","the","they","these","this","for","is","are","was","of","or","and","does","will","whose"};
		while(scn.hasNextLine()){
			String word=scn.nextLine();
			String [] output=word.split("\\s++|\\{|}|<|>|\\(|\\)|\\.|,|;|'|\"|\\?|#|!|-|:");
			for(int j=0;j<output.length;j++){
				if(!isPresent(output[j],connectors)){
					output[j]=output[j].toLowerCase();
				processText(output[j],i,real_position);
				i++;
				real_position++;
			}
			else{
				i++;
			}
			}
		}
	}
	catch(FileNotFoundException e){
		System.out.println("page with name "+pageName+" does not exist.");
	}

	}



	PageIndex getPageIndex(){
		return p;
	}



	private boolean isPresent(String s,String[] arr){ //returns true if the given string is present in the given arary. false otherwise
		for(int i=0;i<arr.length;i++){
			if(s.equals(arr[i])) return true;		
		}
		return false;
	}

	@Override
	public boolean equals(Object o){
		PageEntry p=(PageEntry)o;
		return(p.page_name.equals(this.page_name));
	}


	private void processText(String word,int i,int real_position){

			String [] special_strings={"stack","structure","application"};//contains the words whose plurals have to be taken the same as them
				if(!word.equals("")){
				if(isPresent(word.substring(0,word.length()-1),special_strings)){
					word=word.substring(0,word.length()-1);
					Position pos=new Position(this,i);
					pos.setRealPos(real_position);
					p.addPositionForWord(word,pos);//adding the word's position
					i++;
				}
				//handling the rest of the 'normal' words
				else{
					Position pos=new Position(this,i);
					pos.setRealPos(real_position);
					p.addPositionForWord(word,pos);//adding the word's position
					i++;
				} 
			}
		}

		public float getTermFrequency(String word){
			MyLinkedList<WordEntry> all_the_words=p.getWordEntries();// all_the_words linked list contains all the word entries present in the page
			WordEntry relevant_entry_temp=new WordEntry(word);
			WordEntry relevant_entry_actual=all_the_words.getItem(relevant_entry_temp);
			if(relevant_entry_actual==null)return 0;//if the WordEntry does not exist in the page then its term frequency is 0.  
			int relevant_occurences=relevant_entry_actual.pos.getSize();
			//System.out.println("The count of the relevant occureneces of the word "+word+" in page "+page_name+" is "+relevant_occurences);
			int total_entries=0;
			for(WordEntry w:all_the_words){
				total_entries+=w.pos.getSize();
			}
			float termfreq=(float)(relevant_occurences/(1.0*total_entries));
			//System.out.println("The termfrequency of the word "+word+" in page "+page_name+" is "+termfreq);
			return termfreq;
		}


		public float getRelevanceOfPage(String str[],boolean doTheseWordsRepresentAPhrase){
			float net_relevance=0;//initializing net relevance to 0
			if(doTheseWordsRepresentAPhrase==false){
				for(int id=0;id<str.length;id++){

					net_relevance+=getTermFrequency(str[id])*this.t_ind.getInverseDocumentFrequency(str[id]);
				}
				//System.out.println("The value of net_relevance of the page "+page_name+" is "+net_relevance);
				return net_relevance;
			}
			else{
				float m=numberOfTimes(str);//number of times the phrase occurs in the page
				//System.out.println("value of m for page "+page_name+" is "+m);	
				float k=str.length;//length of the phrase
				MyLinkedList<WordEntry> all_the_words=p.getWordEntries();// all_the_words linked list contains all the word entries present in the page
				float Wp=0;//the total number of words in the page
				for(WordEntry w:all_the_words){
					Wp+=w.pos.getSize();
					//System.out.println("value of Wp for page "+page_name+" is "+Wp);
				}
				//System.out.println("value of Wp for page "+page_name+" is "+Wp);
				float relevance=(this.t_ind.getInverseDocumentFrequencyOfPhrase(str))*(m/(Wp-((k-1)*m)));
				//System.out.println("The relevance of the page "+this.page_name+" is "+net_relevance);
				return relevance;
			}
		}


		public boolean searchForPhrase(String [] str){
			WordEntry temp_first=new WordEntry(str[0]);
			WordEntry real_first=p.entries.getItem(temp_first);
			if(real_first==null)return false;//return false if the first word is not contained in the page index of that page
			MyLinkedList<Position> first_word_positions=real_first.pos;
			for(Position p:first_word_positions){
				boolean flag=true;
				for(int i=1;i<str.length;i++){
					Position temp_pos=new Position(this,0);//the wordIndex of the temporary position is irrelevant. It is the real position that counts while finding out the permanant position
					temp_pos.setRealPos(p.real_index+i);
					//System.out.println("The word at the "+i+"-th position is "+str[i]);
					WordEntry temp=new WordEntry(str[i]);
					WordEntry real=this.p.entries.getItem(temp);
					if(real==null) return false;//returning false if the word entry corresponding to that word does not exist in the page index
					boolean present_or_not=real.pos_ns.find(temp_pos);
					if(!present_or_not){//if the given position is not present in the AVLTree
						flag=false;
						break;
					}
				}
				if(flag==true){
					return true;
				}
			}
			return false;//returns false if none of the beginnings capitalize into proper phrases
		}



		private int numberOfTimes(String [] str){//returns 'm' i.e. the number of times the phrase has occured in the page
			int number_of_times=0;
			WordEntry temp_first=new WordEntry(str[0]);
			WordEntry real_first=p.entries.getItem(temp_first);
			MyLinkedList<Position> first_word_positions=real_first.pos;
			for(Position p:first_word_positions){
				boolean flag=true;
				for(int i=1;i<str.length;i++){
					Position temp_pos=new Position(this,0);//the wordIndex of the temporary position is irrelevant. It is the real position that counts while finding out the permanant position
					temp_pos.setRealPos(p.real_index+i);
					WordEntry temp=new WordEntry(str[i]);
					WordEntry real=this.p.entries.getItem(temp);
					boolean present_or_not=real.pos_ns.find(temp_pos);
					if(!present_or_not){
						flag=false;
						break;
					}
				}
				if(flag==true){
					number_of_times++;
				}
			}
			return number_of_times;//returns false if none of the beginnings capitalize into proper phrases
		}



}
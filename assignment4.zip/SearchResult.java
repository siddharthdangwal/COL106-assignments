public class SearchResult implements Comparable<SearchResult>{

	//the data fields
	PageEntry p;
	float relevance;

	//the constructor
	public SearchResult(PageEntry p, float r){
		this.p=p;
		relevance=r;
	}

	public PageEntry getPageEntry(){
		return p;
	}

	public float getRelavance(){
		return relevance;
	}

	public int compareTo(SearchResult otherObject){//returns 1 if this is more relevant than other object. 0 if both have the same relevance. -1 if the relevance of this is less than the other object's relevance
		if(this.relevance>otherObject.getRelavance()){
			return 1;
		}
		else if(this.relevance<otherObject.getRelavance()){
			return -1;
		}
		else{
			return 0;
		}
	}

}
import java.lang.*;
import java.util.*;
public class MySort{
	public  ArrayList<SearchResult> sortThisList(MySet<SearchResult> listOfSearchResultEntires){
		SearchResult [] a=new SearchResult[listOfSearchResultEntires.Mset.getSize()];//creating an array of size same as that of the MySet
		int i=0;
		for(SearchResult s:listOfSearchResultEntires.Mset){
			a[i]=s;
			i++;
		}
		//the a array now contains all the entries present in the MySet
		SearchResult [] aux=new SearchResult[a.length];//creating an auxilliary array to facilitate the sorting process
		sort(a,aux,0,a.length-1);//doing mergesort from a private function
		ArrayList<SearchResult> sortedList=new ArrayList<SearchResult>();
		for(i=0;i<a.length;i++){
			sortedList.add(a[i]);
		}
		//sortedList is the sorted arrayList
		return sortedList; 
	}


	private void sort(SearchResult [] a, SearchResult [] aux, int lo, int hi){
		if(hi>lo){
			int mid=(hi+lo)/2;
			sort(a,aux,lo,mid);
			sort(a,aux,mid+1,hi);
			merge(a,aux,lo,mid,hi);
			/*System.out.println("The relevance order after sorting is:");
			for(int i=0;i<a.length;i++){
				System.out.print(a[i].getRelavance()+", ");
			}*/
		}
	}


	private void merge(SearchResult[] a, SearchResult [] aux, int lo, int mid, int hi){
		for(int k=lo;k<=hi;k++){
			aux[k]=a[k];
		}
		int j=lo; int k=mid+1;
		for(int i=lo;i<=hi;i++){
			if(j>mid&&k>hi) return ;
			else if(j>mid) a[i]=aux[k++];
			else if(k>hi) a[i]=aux[j++];
			else if(less(aux[j],aux[k])) a[i]=aux[j++];//the one with higher relevance comes before the one with lower relevance
			else a[i]=aux[k++];
		}
		return;

	}

	private boolean less(SearchResult a, SearchResult b){
		return a.compareTo(b)>0;
	}


}                                    
public class WordEntry{
	
	//the data fields
	public String word;
	public MyLinkedList<Position> pos;//the list of indices
	public AVLTree pos_ns;

	//the constructor
	public WordEntry(String word){
		this.word=word;
		pos=new MyLinkedList<Position>();
		pos_ns=new AVLTree();
	}

	//add a position entry for str
	public void addPosition(Position position){
		pos.insertRear(position);
		pos_ns.insert(position);
	}

	// just appending the new list at the end of the pre-existing ones
	public void addPositions(MyLinkedList<Position> positions){
		pos.appendAtRear(positions);
		for(Position p:positions){
			pos_ns.insert(p);//inserting all the new positions in the AVL tree containing positions corresponding to the wordentry 
		}
	}

	//returns a list of all positions for the current word
	public MyLinkedList<Position> getAllPositionsForThisWord(){
		return pos;
	}

	@Override
	public boolean equals(Object o){
		if(o==null)return false;
		WordEntry w=(WordEntry)o;
		if(w.word.equals(this.word)) return true;
		else return false;
	}

}
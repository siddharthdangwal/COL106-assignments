import java.util.*;
public class SearchEngine{

	InvertedPageIndex word_locations;//the Inverted Page index that contains strings and their positions in different web pages

	public SearchEngine(){
		word_locations=new InvertedPageIndex();//initialized to an empty InvertedPageIndex
	}

	public void performAction(String actionMessage){
		int i=0,j=0;
		String[] output=actionMessage.split(" ");
		while(!actionMessage.substring(i,i+1).equals(" "))i++;
		String command=actionMessage.substring(0,i);
		command=output[0];
		//adding a new page to the inverted index
		if(command.equals("addPage")){
			String page_name=actionMessage.substring(i+1,actionMessage.length());
			PageEntry new_page=new PageEntry(page_name);
			word_locations.addPage(new_page);
		}

		//which pages contain which word
		else if(command.equals("queryFindPagesWhichContainWord")){
			String word_name=actionMessage.substring(i+1,actionMessage.length());
			if(word_name.equals("stacks")||word_name.equals("structures")||word_name.equals("applications")){
				word_name=word_name.substring(0,word_name.length()-1);
			}
			MySet<PageEntry> relevant_pages=word_locations.getPagesWhichContainWord(word_name.toLowerCase());
			MySet<SearchResult> results=new MySet<SearchResult>();
			if(relevant_pages==null||relevant_pages.IsEmpty()){
				System.out.println("No webpage contains word "+word_name);
			}//if there are no relevant pages then
			else{
				String[] the_str=new String[1];
			for(PageEntry p:relevant_pages.Mset){
				//String[] the_str=new String[1];
				the_str[0]=word_name;
				SearchResult result=new SearchResult(p,p.getRelevanceOfPage(the_str,false));
				results.Insert(result);
			}
			MySort ms=new MySort();
			ArrayList<SearchResult> sorted_results=ms.sortThisList(results);
			//Node<PageEntry> current=relevant_pages.Mset.head;
			String output_string="";
			for(SearchResult sr:sorted_results){
				output_string=output_string+sr.getPageEntry().page_name+/*", "+sr.getPageEntry().getRelevanceOfPage(the_str,false)+*/", ";
			}
			output_string=output_string.substring(0,output_string.length()-2);
			System.out.println(output_string);
		}
		}

		//positions of words in a page
		else if(command.equals("queryFindPositionsOfWordInAPage")){
			while(!actionMessage.substring(i+j+1,i+j+2).equals(" "))j++;
			String relevant_word=actionMessage.substring(i+1,i+j+1);// the word to be found
			String doc_name=actionMessage.substring(i+j+2,actionMessage.length());//the name of the page
			if(!word_locations.page_names.isPresent(doc_name)) System.out.println("No webpage "+doc_name+" found.");
			else{
			WordEntry temp_word_entry=new WordEntry(relevant_word.toLowerCase());
			PageEntry temp_entry=new PageEntry(doc_name);//creating a temporary page entry corresponding to the page name
			MySet<PageEntry> relevant_pages_corresponding_to_word=word_locations.getPagesWhichContainWord(relevant_word);
			if(relevant_pages_corresponding_to_word==null){
				System.out.println("Webpage "+doc_name+" does not contain word "+relevant_word);
			}
			else{    
			if(!relevant_pages_corresponding_to_word.Mset.isPresent(temp_entry)){
				System.out.println("Webpage "+doc_name+" does not contain word "+relevant_word);
			}
			else{
				PageEntry real_relevant_page=relevant_pages_corresponding_to_word.Mset.getItem(temp_entry);//contains pointer to the relevant page entry inside the linked list of MySet
				WordEntry the_word_in_that_page=real_relevant_page.p.entries.getItem(temp_word_entry);
				Node<Position> current=the_word_in_that_page.pos.head;//points to the head of the positions linked list inside the word entry
				String output_string="";
				int previous_pos=0;
				while(current!=null){
					if(current.data.getWordIndex()>previous_pos){
					output_string=output_string+Integer.toString(current.data.getWordIndex())+", ";
					previous_pos=current.data.getWordIndex();
					current=current.next;
				}
				else{
					break;
				}
				}
				output_string=output_string.substring(0,output_string.length()-2);
				System.out.println(output_string);
			}
		}
		}
	}

	else if(command.equals("queryFindPagesWhichContainAllWords")){
		MyLinkedList<PageEntry> list_of_all_pages=word_locations.page_entries_added;//this is the list of all the pages currently present in the inverted_index
		MySet<PageEntry> set_of_all_pages_relevant_pages=new MySet<PageEntry>();
		set_of_all_pages_relevant_pages.Insert(list_of_all_pages);//all the pages presernt in the inverted index currently added to the set
		for(int t=1;t<output.length;t++){
			MySet<PageEntry> pages_which_contain_this_word=word_locations.getPagesWhichContainWord(output[t]);
			set_of_all_pages_relevant_pages=set_of_all_pages_relevant_pages.Intersection(pages_which_contain_this_word);
		}
		String []search_words=new String[output.length-1];
		for(int p=1;p<output.length;p++){
			search_words[p-1]=output[p];
		}
		//set of all relevant pages contains only those pages which have all of these words present in them
		MySet<SearchResult> all_the_search_results=new MySet<SearchResult>();
		for(PageEntry p:set_of_all_pages_relevant_pages.Mset){
			SearchResult sr=new SearchResult(p,p.getRelevanceOfPage(search_words,false));//making a new SearchResult object and creating a set of all these SearchResults
			all_the_search_results.Insert(sr);
		}
		MySort ms=new MySort();
		ArrayList<SearchResult> sortedSearchResults=ms.sortThisList(all_the_search_results);
		String pages="";
		for(SearchResult sr: sortedSearchResults){
			pages=pages+sr.getPageEntry().page_name/*+" "+sr.getPageEntry().getRelevanceOfPage(search_words,false)*/+", ";
		}
		pages=pages.substring(0,pages.length()-2);
		System.out.println(pages);//printing the string containing the names of all the pages in order of relevance

	}

	else if(command.equals("queryFindPagesWhichContainAnyOfTheseWords")){
		MyLinkedList<PageEntry> list_of_all_pages=word_locations.page_entries_added;//this is the list of all the pages currently present in the inverted_index
		MySet<PageEntry> set_of_all_pages_relevant_pages=new MySet<PageEntry>();
		for(int p=1;p<output.length;p++){
			MySet<PageEntry> pages_which_contain_this_word=word_locations.getPagesWhichContainWord(output[p]);
			set_of_all_pages_relevant_pages=set_of_all_pages_relevant_pages.Union(pages_which_contain_this_word);//all the pages which contain any of these words are present in this list
		}
		String []search_words=new String[output.length-1];
		for(int p=1;p<output.length;p++){
			search_words[p-1]=output[p];
		}
		//set_of_all_relevant_pages contains all those words which contain even 1 of all the words
		MySet<SearchResult> all_the_search_results=new MySet<SearchResult>();
		for(PageEntry p:set_of_all_pages_relevant_pages.Mset){
			SearchResult sr=new SearchResult(p,p.getRelevanceOfPage(search_words,false));//making a new SearchResult object and creating a set of all these SearchResults
			all_the_search_results.Insert(sr);
		}
		MySort ms=new MySort();
		ArrayList<SearchResult> sortedSearchResults=ms.sortThisList(all_the_search_results);
		String pages="";
		for(SearchResult sr: sortedSearchResults){
			pages=pages+sr.getPageEntry().page_name/*+" "+sr.getPageEntry().getRelevanceOfPage(search_words,false)*/+", ";
		}
		pages=pages.substring(0,pages.length()-2);
		System.out.println(pages);//printing the string containing the names of all the pages in order of relevance

		
	}

	else if(command.equals("queryFindPagesWhichContainPhrase")){
		String []phrase=new String[output.length-1];
		String ph="";
		for(int d=1;d<output.length;d++){
			phrase[d-1]=output[d];
			ph=ph+output[d]+" ";
		}
		//phrase array contains all the words that make up the phrase
		MySet<PageEntry> pages_containing_phrase=word_locations.getPagesWhichContainPhrase(phrase);
		MySet<SearchResult> all_the_search_results=new MySet<SearchResult>();
		for(PageEntry p:pages_containing_phrase.Mset){
			SearchResult sr=new SearchResult(p,p.getRelevanceOfPage(phrase,true));//making a new SearchResult object and creating a set of all these SearchResults
			all_the_search_results.Insert(sr);
		}
		MySort ms=new MySort();
		ArrayList<SearchResult> sortedSearchResults=ms.sortThisList(all_the_search_results);
		String pages="";
		for(SearchResult sr: sortedSearchResults){
			pages=pages+sr.getPageEntry().page_name+" "+sr.getPageEntry().getRelevanceOfPage(phrase,true)+", ";
		}
		if(pages.equals("")){
			System.out.println("No page contains the phrase "+ph);
		}
		else{
		pages=pages.substring(0,pages.length()-2);
		System.out.println(pages);//printing the string containing the names of all the pages in order of relevance
		}
	}

	}
}
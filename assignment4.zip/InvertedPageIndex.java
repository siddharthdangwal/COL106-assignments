public class InvertedPageIndex{

	public MyHashTable words_and_positions;//the hash table which stores all the
	public MyLinkedList<String> page_names;
	public MyLinkedList<PageEntry> page_entries_added; 

	public InvertedPageIndex(){
		words_and_positions=new MyHashTable();
		page_names=new MyLinkedList<String>();
		page_entries_added=new MyLinkedList<PageEntry>();
	}

	public void addPage(PageEntry p){
		page_entries_added.insertFront(p);//inserting into the linked list that keeps track of all the page entries that have been added to the inverted page index.
		PageIndex p_page_index=p.getPageIndex();//p_page_index contains the linked list of all words and their positions in the PageEntry "p"
		String p_name=p.page_name;//the name of the webpage
		page_names.insertFront(p_name);//inserting the name in the linked list storing the names of all the pages added
		MyLinkedList<WordEntry> p_page_index_word_entries=p_page_index.getWordEntries();//p-page_index_word_entries is the linked list that contains all words and their positions
		Node<WordEntry> current=p_page_index_word_entries.head;
		while(current!=null){
			words_and_positions.addPositionsForWord(current.data);//adding the word entries present in the page entry of that webpage into the inverted index.
			current=current.next;
		}
		for(PageEntry pg:page_entries_added){
			pg.t_ind=this;//making the pointer pointing to the inverted page index equal to the current inverted index after every page addition;
		}
	}

	public MySet<PageEntry> getPagesWhichContainWord(String str){
		MySet<PageEntry> relevant_pages=new MySet<PageEntry>();//the MySet that contains all the relevant pages to the query string
		WordEntry in_the_hash_table=words_and_positions.find(str);//returns a pointer to the WordEntry corresponding to this string present inside the hashtable
		if(in_the_hash_table==null)return null;//if this is null means that this word does not exist in the hash table
		
		else{
		MyLinkedList<Position> all_the_positions=in_the_hash_table.getAllPositionsForThisWord();//stores the postions of that word entry
		for(Position position:all_the_positions){
			PageEntry p=position.getPageEntry();
			if(!relevant_pages.IsMember(p)){
			relevant_pages.Insert(p);//stores the PageEntries corresponding the locations of a WordEntry
			}
			
		}
		return relevant_pages;
	}
	}

	public MySet<PageEntry> getPagesWhichContainPhrase(String str[]){
		MySet<PageEntry> relevant_pages=new MySet<PageEntry>();
		for(PageEntry p:page_entries_added){
			boolean flag=p.searchForPhrase(str);
			if(flag)relevant_pages.Insert(p);
		}
		return relevant_pages;
	}

	public float getInverseDocumentFrequency(String str){
		WordEntry real_word=words_and_positions.find(str);//returns the WordEntry corresponding to that string 
		float N=page_entries_added.getSize();
		float nw=0;
		for(PageEntry p:page_entries_added){
			WordEntry temp_entry=new WordEntry(str);//making a temporary word entry corresponding to the st
			if(p.p.entries.isPresent(temp_entry)){
				nw++;//increasing nw if the page contains the word;
			}
		}
		float freq=(float)(Math.log((N*1.0)/nw));
		//System.out.println("The value of inverse document frequency of the word "+str+" is "+freq);
		return freq;
	}

	public float getInverseDocumentFrequencyOfPhrase(String [] str){
		float N=page_entries_added.getSize();
		float nw=0;//initializing the value giving "the number of pages which contain the given word" to zero.
		MySet<PageEntry> relevant_pages=getPagesWhichContainPhrase(str);
		nw=relevant_pages.Mset.getSize();
		return (float)Math.log(N*1.0/nw);
	}
}
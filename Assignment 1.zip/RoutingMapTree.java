import java.util.*;

/*The Myset class*/
 class Myset<Object>{

	/*the data field of the Myset class*/
	public LinkedList<Object> Mset;

	public Myset (){
		Mset=new LinkedList<Object>();
	}



	public Boolean IsEmpty(){
		return Mset.isEmpty();
	}

	public Boolean IsMember(Object o){
		for(Object temp:Mset){
			if(temp.equals(o))return true;
		}
		return false;
	}

	public void Insert(Object o){
		Mset.insertAtEnd(o);//insert at start increases the size of the list by itself.No need to increase size here as well.
	}

	public void Delete(Object o){
		int i=1;
		boolean flag=false;
		for(Object temp:Mset){
			if(temp.equals(o)) {
				flag=true;
				break;
			}
			else {
				i++;
			}
		}
		if(flag==true){
			Mset.deleteAtPos(i);
			Mset.size--;
		}
		else{
			throw new java.util.NoSuchElementException();
		}
		
	}

	public Myset Union(Myset<Object> a){
		Myset<Object> union=new Myset<Object>();
		for(Object temp:a.Mset){
			union.Insert(temp);	//transfer all elements of the linked list a into the new Union linkedList
		}
		for(Object temp:this.Mset){
			if(!(union.IsMember(temp))){
			union.Insert(temp); //transfer all elements of the linked list self into the new Union linkedList
			} 
		}

		return union;
	}

	public Myset Intersection(Myset<Object> a){
		Myset intersection=new Myset();
		for(Object temp:Mset){
			intersection.Insert(temp);
		}
		for(Object temp:a.Mset){//checking whether the elements transferred to the intersection Myset has its elements in the a Myset also. If it does 
																//then the element is kept .else it is deleted
			if(!intersection.IsMember(temp)){
				intersection.Delete(temp);//deleting the non common elements
			}
		}
		return intersection;
	}


}





 class MobilePhone{
	int number;  //the field element of the class
	boolean status;//this defines the switched on/switched off state of the mobile phone. true= switched on and false=switched off
	Exchange base;//the base to which the mobile phone is connected

	public MobilePhone(int number){
		this.number=number;
		this.status=true;//originally sqitched on
	}
	public Boolean status(){
		return this.status;
	}
	public void switchOn(){
		status=true;
	}
	public void switchOff(){
		status=false;
	}
	public Exchange location(){
		//code
		return this.base;
	}
	public void setLocation(Exchange location){
		this.base=location;
	}
	@Override public boolean equals(Object other){
		assert (other instanceof MobilePhone);
		MobilePhone c=(MobilePhone)other;
		return this.number==c.number;  //the two mobile phones are equal if their numbers are the same
	}


}





/*the node class*/
class Node<Object>
{
    public Object data;
    public Node<Object> link;
 
    /*  Constructor  */
    public Node ()
    {
        link = null;
        data = null;
    }    
    /*  Constructor  */
    public Node (Object d,Node<Object> n)
    {
        data = d;
        link = n;
    }    
    /*  Function to set link to next Node  */
    public void setLink(Node<Object> n)
    {
        link = n;
    }    
    /*  Function to set data to current Node  */
    public void setData(Object d)
    {
        data = d;
    }    
    /*  Function to get link to next node  */
    public Node<Object> getLink()
    {
        return link;
    }    
    /*  Function to get data from current Node  */
    public Object getData()
    {
        return data;
    }
}
 



/* Class linkedList */
  class LinkedList<Object> implements Iterable<Object>
{
    private Node<Object> start;
    private Node<Object> end;
    protected int size;
 
    /*  Constructor  */
    public LinkedList()
    {
        start = null;
        end = null;
        size = 0;
    }
    /*  Function to check if list is empty  */
    public boolean isEmpty()
    {
        return start == null;
    }
    /*  Function to get size of list  */
    public int getSize()
    {
        return size;
    }    
    /*  Function to insert an element at begining  */
    public void insertAtStart(Object val)
    {
        Node<Object> nptr = new Node<Object>(val, null);    
        size++ ;    
        if(start == null) 
        {
            start = nptr;
            end = start;
        }
        else 
        {
            nptr.setLink(start);
            start = nptr;
        }
    }
    /*  Function to insert an element at end  */
    public void insertAtEnd(Object val)
    {
        Node<Object> nptr = new Node<Object>(val,null);    
        size++ ;    
        if(start == null) 
        {
            start = nptr;
            end = start;
        }
        else 
        {
            end.setLink(nptr);
            end = nptr;
        }
    }
    /*  Function to insert an element at position  */
    public void insertAtPos(Object val , int pos)
    {
        Node<Object> nptr = new Node<Object>(val, null);                
        Node<Object> ptr = start;
        pos = pos - 1 ;
        for (int i = 1; i < size; i++) 
        {
            if (i == pos) 
            {
                Node<Object> tmp = ptr.getLink() ;
                ptr.setLink(nptr);
                nptr.setLink(tmp);
                break;
            }
            ptr = ptr.getLink();
        }
        size++ ;
    }
    /*  Function to delete an element at position  */
    public void deleteAtPos(int pos)
    {        
        if (pos == 1) 
        {
            start = start.getLink();
            size--; 
            return ;
        }
        if (pos == size) 
        {
            Node s = start;
            Node t = start;
            while (s != end)
            {
                t = s;
                s = s.getLink();
            }
            end = t;
            end.setLink(null);
            size --;
            return;
        }
        Node ptr = start;
        pos = pos - 1 ;
        for (int i = 1; i < size - 1; i++) 
        {
            if (i == pos) 
            {
                Node tmp = ptr.getLink();
                tmp = tmp.getLink();
                ptr.setLink(tmp);
                break;
            }
            ptr = ptr.getLink();
        }
        size-- ;
    }
    /*function to get the node at location i. Indexing starts at 0*/ 
    public Object get(int i){
        try{
            Node<Object>current=this.start;
            for(int j=0;j<i;j++){
                current=current.link;
            }
            return current.data;
        }
        catch(java.lang.NullPointerException e){
            return null;
        }
    }
    /*function to return an iterator of the linked list*/
    public Iterator<Object> iterator(){
    	return new linkedListIterator();
    }

    public Object getCopyInside(Object o){//returns the pointer to the object of the same specification present inside the linkedList
    	Node <Object>current=new Node<Object>();
    	current=this.start;
        if(current==null) throw new java.util.NoSuchElementException();
    	while(current!=null){
    		if(current.data.equals(o)){
    			return current.data;
    		}
    		current=current.link;
    	}
    	return current.data;
    }

    class linkedListIterator implements Iterator<Object>{
    	Node <Object>current;

    	public linkedListIterator(){
    		current=LinkedList.this.start;
    	}

    	public boolean hasNext(){
    		return current!=null;
    	}

    	public Object next(){
    	   Object obj=current.data;
           current=current.link;
           return obj;
    	}

    	public void remove(){
    		throw new java.lang.UnsupportedOperationException();
    	}

    }
}

 
 
 
 

 class Exchange{
	
	public int number;//the unique identifier of the exchange class
	public Exchange parent;//the parent of the given exchange
	public ExchangeList children;//this linked list contains all the children of a particular exchange
	public MobilePhoneSet m_set;//this has all the mobile phones that come under that particular exchange


	public Exchange(int number){
		this.number=number;
		parent=null;
		children=new ExchangeList();
		m_set=new MobilePhoneSet();
	}

	public void setParent(Exchange a){
		parent=a;
	}

	public Exchange parent(){
		return parent;
	}

	public int numChildren(){
		try{
		return children.ch.getSize();
	}
	catch(NullPointerException e){
		return 0;
	}
	}

	public Exchange child(int i){
		return children.ch.get(i);
	}

	public Boolean isRoot(){
		return (parent==null);
	}

	public void addChild(Exchange b){
		this.children.ch.insertAtEnd(b);
		this.m_set.mobile_set=this.m_set.mobile_set.Union(b.m_set.mobile_set);
	}

	public RoutingMapTree subtree(int i){
		//code
		return new RoutingMapTree(child(i)); //returns a RoutingMapTree with the child at integer i as its root
	}

	public MobilePhoneSet residentSet(){
		return m_set;//returns the resident set of the exchange which has all the mobile phones that come under this exchange;
	}

	@Override public boolean equals(Object other){
		assert(other instanceof Exchange);
		Exchange c=(Exchange)other;
		return (this.number==c.number); //the two exhanges are equal if their unique identifiers i.e. the numbers characteristic of them are the same
	}


}





 class ExchangeList{
	public LinkedList<Exchange> ch;
	public ExchangeList(){
		ch=new LinkedList<Exchange>();
	}
}




 class MobilePhoneSet{
	public Myset<MobilePhone> mobile_set;
	public MobilePhoneSet(){
		mobile_set=new Myset<MobilePhone>();
	}
}





	public class RoutingMapTree{

		private Exchange root;//the root node of the tree
		private MobilePhoneSet switched_on_phones;//has the pointer to all the switched on phones present in the RoutingMapTree data structure 

		public RoutingMapTree() {

			root=new Exchange(0);//this forms the root of the RoutingMapTree data structure
			switched_on_phones=new MobilePhoneSet();
		}
		
		public RoutingMapTree(Exchange e){
			root=e;
		}

		/*given a particular exchange a determines whether it is in the tree or not*/
		public boolean containsNode(Exchange a){
			//calls a private recursive function that finds out whether the node is contained in the tree or not
			return containsNode(this.root,a);
		}

		private Exchange NodeInTree(Exchange root,Exchange a){		 
		//assuming that a node equal to the node a is present in the tree we return the pointer to the original node present in the tree															
			boolean flag=false;
			if(root.numChildren()==0){
				if(root.equals(a)==true){// replacing a in-place of the root in the tree. Pending : the parent of b will still be pointing to the earlier node.correct that as well
					return root;
				}
			}
			else{//create a getIndex function for finding the position of the root in its parent's node
				flag=root.equals(a);
				if(flag==true){
					return root;
				}
				else{
					for(int i=0;i<root.numChildren();i++){
						flag=containsNode(root.child(i),a);
						if(flag==true){
							return NodeInTree(root.child(i),a);
						}
					}
				}
			}
			return null;//this is unreachable
		}

		private boolean containsNode(Exchange root,Exchange a){		//tells whether the tree contains the given Exchange node or not and if it does exchanges that 
			boolean flag=false;										//position with a node passed as a parameter
			if(root.numChildren()==0){
				if(root.equals(a)==true){// replacing a in-place of the root in the tree. Pending : the parent of b will still be pointing to the earlier node.correct that as well
					
					return true;
				}
				else{
					return false;
				}
			}
			else{//create a getIndex function for finding the position of the root in its parent's node
				flag=root.equals(a);
				if(flag==true){
					
					return flag;
				}
				else{
					for(int i=0;i<root.numChildren();i++){
						flag=containsNode(root.child(i),a);
						if(flag==true){
							
							return flag;
						}
					}
				}
			}
			return flag;
		}


		public void switchOn(MobilePhone a,Exchange b){
			a.switchOn();
			if(containsNode(b)){
			b.m_set.mobile_set.Insert(a);
			switched_on_phones.mobile_set.Insert(a);//inserting into the RoutingMapTree MobilePhoneSet
		}
	}

		public void switchOff(MobilePhone a){
			switchOff(a,root);// a private function that is used to switch off the phones
	}

	private void switchOff(MobilePhone a,Exchange root){
		if(root.m_set.mobile_set.IsMember(a)){
			if(root.numChildren()==0){//checking if the current node is an external node or not
				MobilePhone real_phone;
				real_phone=root.m_set.mobile_set.Mset.getCopyInside(a);//get the real copy from inside the linked list
				real_phone.switchOff();//switch it off
				root.m_set.mobile_set.Delete(real_phone);
				//System.out.println("the phone number's "+real_phone.number+" status is "+real_phone.status);
				return;
			}
			else{
				MobilePhone real_phone;
				real_phone=root.m_set.mobile_set.Mset.getCopyInside(a);
				real_phone.switchOff();
				root.m_set.mobile_set.Delete(real_phone);
				for(int i=0;i<root.numChildren();i++){
					if(root.child(i).m_set.mobile_set.IsMember(a)){//check for the node child which has the mobile phone as its member
						switchOff(a,root.child(i));//switch it off there as well
						return;
					}
				}
			}
		}
	}

		public String performAction(String actionMessage) {
			int i=0;

			while(!(actionMessage.substring(i,i+1).equals(" "))){
				i++;
			}

			String command=actionMessage.substring(0,i);//the string command contains the text part of the input command

			if(command.equals("addExchange")){//handling the "addExchange" command
				int j=1;
				while(!(actionMessage.substring(i+j,i+j+1).equals(" ")))j++;
				int parent_exchange_identifier=Integer.parseInt(actionMessage.substring(i+1,i+j));
				int child_exchange_identifier=Integer.parseInt(actionMessage.substring(i+j+1,actionMessage.length()));
				Exchange a_temp=new Exchange(parent_exchange_identifier);
				try{
				if(containsNode(a_temp)){//checking if the parent exchange is present in the routing map tree
					Exchange real_exchange=NodeInTree(root,a_temp);
					Exchange b=new Exchange(child_exchange_identifier);
					b.setParent(real_exchange);
					real_exchange.addChild(b);//adding a new child to the parent if it is present in the routing map tree
				}
				else{
					throw new Exception();//throws an excpetion if no such element as the parent a is present in the tree.
				}
			}
			catch(Exception e){
				System.out.println("Exception-Exchange with identifier "+parent_exchange_identifier+" couldn't be found.");
			}
			return "";
			}

			else if(command.equals("switchOnMobile")){
				
				int j=1;
				while(!(actionMessage.substring(i+j,i+j+1).equals(" ")))j++;
				int mobile_identifier=Integer.parseInt(actionMessage.substring(i+1,i+j));
				int parent_exchange_identifier=Integer.parseInt(actionMessage.substring(i+j+1,actionMessage.length()));
				Exchange a_temp=new Exchange(parent_exchange_identifier);
				try{
				if(containsNode(a_temp)){
					Exchange real_exchange=NodeInTree(root,a_temp);
					MobilePhone phone_temp=new MobilePhone(mobile_identifier);
					if(real_exchange.m_set.mobile_set.IsMember(phone_temp)){//checking if the phone is already the part of the exchange
						MobilePhone real_phone=a_temp.m_set.mobile_set.Mset.getCopyInside(phone_temp);
						real_phone.switchOn();
						//switched_on_phones.mobile_set.Insert(real_phone);//inserting a pointer to the real phone in the switched_on_phones set
					}
					else{//if the phone is already not present in the exchange just create a new phone and put it in
						phone_temp.switchOn();
						phone_temp.setLocation(real_exchange);
						real_exchange.m_set.mobile_set.Insert(phone_temp);
						//switched_on_phones.mobile_set.Insert(phone_temp);//inserting a pointer to the phone in the switched_on_phones set
						while(real_exchange.parent()!=null){
							real_exchange=real_exchange.parent();
							real_exchange.m_set.mobile_set.Insert(phone_temp);
						}

					}
				}
				else{
					throw new Exception();
				}
			}
			catch(Exception e){
				System.out.println("Exception-Exchange with identifier "+parent_exchange_identifier+" couldn't be found.");
			}
			return "";
			}

			else if(command.equals("switchOffMobile")){
				//code
				int mobile_phone_identifier=Integer.parseInt(actionMessage.substring(i+1,actionMessage.length()));
				MobilePhone temp_phone=new MobilePhone(mobile_phone_identifier);
				try{
				if(root.m_set.mobile_set.IsMember(temp_phone)){
					switchOff(temp_phone);
				}
				else{
					throw new Exception();
				}
			}
			catch(Exception e){
				System.out.println("Exception-MobilePhone with identifier "+mobile_phone_identifier+" does not exist.");
			}
			return "";
			}

			else if(command.equals("queryNthChild")){
				int j=1;
				while(!(actionMessage.substring(i+j,i+j+1).equals(" ")))j++;
				int exchange_identifier=Integer.parseInt(actionMessage.substring(i+1,i+j));
				int child_number=Integer.parseInt(actionMessage.substring(i+j+1,actionMessage.length()));
				Exchange identifier_temp=new Exchange(exchange_identifier);
				try{
				if(containsNode(identifier_temp)){
						Exchange real_exchange=NodeInTree(root,identifier_temp);
						if(real_exchange==null)throw new Exception();
						//System.out.println("the identifier of the child exchange (queryNthChild) is "+real_exchange.child(child_number).number);//printing the value of the bth child 
						String str="queryNthChild "+actionMessage.substring(i+1,i+j)+" "+actionMessage.substring(i+j+1,actionMessage.length())+": "+Integer.toString(real_exchange.child(child_number).number);
						//System.out.println(str);
						return str;
				}
				else{
					throw new Exception();
				}
			}
			catch(Exception e){
				System.out.println("Exception-Exchange does not exist.");
			}
			}

			else if(command.equals("queryMobilePhoneSet")){
				int exchange_identifier=Integer.parseInt(actionMessage.substring(i+1,actionMessage.length()));
				Exchange identifier_temp=new Exchange(exchange_identifier);
				try{
				if(containsNode(identifier_temp)){
					Exchange real_exchange=NodeInTree(root,identifier_temp);
					MobilePhoneSet r_set=real_exchange.m_set;//the mobile phone set of the node
					//System.out.print("The number of elements in the exhange is "+r_set.mobile_set.Mset.getSize()+". The phone number of the phone number query of exchange "+exchange_identifier+"(queryPhoneNumber) is ");
					String str="queryMobilePhoneSet "+Integer.toString(exchange_identifier)+": ";
					for(MobilePhone ph:r_set.mobile_set.Mset){//for all the mobile phones in the set Mset
							//System.out.print(ph.number+" ");//prints the number of the mobile phone
							str=str+Integer.toString(ph.number)+", "; 
					}
					//System.out.print("\n");
					
					//System.out.println(str);
					return str.substring(0,str.length()-2);
				}
				else{
					throw new Exception();
				}
			}
			catch(Exception e){
				System.out.println("Exception-exchange with identifier "+exchange_identifier+" does not exist");
			}
			}
			return "";

		}
	}

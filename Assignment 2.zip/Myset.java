import java.util.*;

/*The Myset class*/
 class Myset<Object>{

	/*the data field of the Myset class*/
	public LinkedList<Object> Mset;

	public Myset (){
		Mset=new LinkedList<Object>();
	}



	public Boolean IsEmpty(){
		return Mset.isEmpty();
	}

	public Boolean IsMember(Object o){
		for(Object temp:Mset){
			if(temp.equals(o))return true;
		}
		return false;
	}

	public void Insert(Object o){
		Mset.insertAtEnd(o);//insert at start increases the size of the list by itself.No need to increase size here as well.
	}

	public void Delete(Object o){
		int i=1;
		boolean flag=false;
		for(Object temp:Mset){
			if(temp.equals(o)) {
				flag=true;
				break;
			}
			else {
				i++;
			}
		}
		if(flag==true){
			Mset.deleteAtPos(i);
			Mset.size--;
		}
		else{
			throw new java.util.NoSuchElementException();
		}
		
	}

	public Myset Union(Myset<Object> a){
		Myset<Object> union=new Myset<Object>();
		for(Object temp:a.Mset){
			union.Insert(temp);	//transfer all elements of the linked list a into the new Union linkedList
		}
		for(Object temp:this.Mset){
			if(!(union.IsMember(temp))){
			union.Insert(temp); //transfer all elements of the linked list self into the new Union linkedList
			} 
		}

		return union;
	}

	public Myset Intersection(Myset<Object> a){
		Myset intersection=new Myset();
		for(Object temp:Mset){
			intersection.Insert(temp);
		}
		for(Object temp:a.Mset){//checking whether the elements transferred to the intersection Myset has its elements in the a Myset also. If it does 
																//then the element is kept .else it is deleted
			if(!intersection.IsMember(temp)){
				intersection.Delete(temp);//deleting the non common elements
			}
		}
		return intersection;
	}


}
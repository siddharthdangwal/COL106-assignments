import java.util.*;
/*the node class*/
class Node<Object>
{
    public Object data;
    public Node<Object> link;
 
    /*  Constructor  */
    public Node ()
    {
        link = null;
        data = null;
    }    
    /*  Constructor  */
    public Node (Object d,Node<Object> n)
    {
        data = d;
        link = n;
    }    
    /*  Function to set link to next Node  */
    public void setLink(Node<Object> n)
    {
        link = n;
    }    
    /*  Function to set data to current Node  */
    public void setData(Object d)
    {
        data = d;
    }    
    /*  Function to get link to next node  */
    public Node<Object> getLink()
    {
        return link;
    }    
    /*  Function to get data from current Node  */
    public Object getData()
    {
        return data;
    }
}
 



/* Class linkedList */
  class LinkedList<Object> implements Iterable<Object>
{
    private Node<Object> start;
    private Node<Object> end;
    protected int size;
 
    /*  Constructor  */
    public LinkedList()
    {
        start = null;
        end = null;
        size = 0;
    }
    /*  Function to check if list is empty  */
    public boolean isEmpty()
    {
        return start == null;
    }
    /*  Function to get size of list  */
    public int getSize()
    {
        return size;
    }    
    /*  Function to insert an element at begining  */
    public void insertAtStart(Object val)
    {
        Node<Object> nptr = new Node<Object>(val, null);    
        size++ ;    
        if(start == null) 
        {
            start = nptr;
            end = start;
        }
        else 
        {
            nptr.setLink(start);
            start = nptr;
        }
    }
    /*  Function to insert an element at end  */
    public void insertAtEnd(Object val)
    {
        Node<Object> nptr = new Node<Object>(val,null);    
        size++ ;    
        if(start == null) 
        {
            start = nptr;
            end = start;
        }
        else 
        {
            end.setLink(nptr);
            end = nptr;
        }
    }
    /*  Function to insert an element at position  */
    public void insertAtPos(Object val , int pos)
    {
        Node<Object> nptr = new Node<Object>(val, null);                
        Node<Object> ptr = start;
        pos = pos - 1 ;
        for (int i = 1; i < size; i++) 
        {
            if (i == pos) 
            {
                Node<Object> tmp = ptr.getLink() ;
                ptr.setLink(nptr);
                nptr.setLink(tmp);
                break;
            }
            ptr = ptr.getLink();
        }
        size++ ;
    }
    /*  Function to delete an element at position  */
    public void deleteAtPos(int pos)
    {        
        if (pos == 1) 
        {
            start = start.getLink();
            size--; 
            return ;
        }
        if (pos == size) 
        {
            Node s = start;
            Node t = start;
            while (s != end)
            {
                t = s;
                s = s.getLink();
            }
            end = t;
            end.setLink(null);
            size --;
            return;
        }
        Node ptr = start;
        pos = pos - 1 ;
        for (int i = 1; i < size - 1; i++) 
        {
            if (i == pos) 
            {
                Node tmp = ptr.getLink();
                tmp = tmp.getLink();
                ptr.setLink(tmp);
                break;
            }
            ptr = ptr.getLink();
        }
        size-- ;
    }
    /*function to get the node at location i. Indexing starts at 0*/ 
    public Object get(int i){
        try{
            Node<Object>current=this.start;
            for(int j=0;j<i;j++){
                current=current.link;
            }
            return current.data;
        }
        catch(java.lang.NullPointerException e){
            return null;
        }
    }
    /*function to return an iterator of the linked list*/
    public Iterator<Object> iterator(){
    	return new linkedListIterator();
    }

    public Object getCopyInside(Object o){//returns the pointer to the object of the same specification present inside the linkedList
    	Node <Object>current=new Node<Object>();
    	current=this.start;
        if(current==null) throw new java.util.NoSuchElementException();
    	while(current!=null){
    		if(current.data.equals(o)){
    			return current.data;
    		}
    		current=current.link;
    	}
    	return current.data;
    }

    class linkedListIterator implements Iterator<Object>{
    	Node <Object>current;

    	public linkedListIterator(){
    		current=LinkedList.this.start;
    	}

    	public boolean hasNext(){
    		return current!=null;
    	}

    	public Object next(){
    	   Object obj=current.data;
           current=current.link;
           return obj;
    	}

    	public void remove(){
    		throw new java.lang.UnsupportedOperationException();
    	}

    }
}

 
import java.util.*;
 class Exchange{
	
	public int number;//the unique identifier of the exchange class
	public Exchange parent;//the parent of the given exchange
	public ExchangeList children;//this linked list contains all the children of a particular exchange
	public MobilePhoneSet m_set;//this has all the mobile phones that come under that particular exchange


	public Exchange(int number){
		this.number=number;
		parent=null;
		children=new ExchangeList();
		m_set=new MobilePhoneSet();
	}

	public void setParent(Exchange a){
		parent=a;
	}

	public Exchange parent(){
		return parent;
	}

	public int numChildren(){
		try{
		return children.ch.getSize();
	}
	catch(NullPointerException e){
		return 0;
	}
	}

	public Exchange child(int i){
		return children.ch.get(i);
	}

	public Boolean isRoot(){
		return (parent==null);
	}

	public void addChild(Exchange b){
		this.children.ch.insertAtEnd(b);
		this.m_set.mobile_set=this.m_set.mobile_set.Union(b.m_set.mobile_set);
	}

	public RoutingMapTree subtree(int i){
		//code
		return new RoutingMapTree(child(i)); //returns a RoutingMapTree with the child at integer i as its root
	}

	public MobilePhoneSet residentSet(){
		return m_set;//returns the resident set of the exchange which has all the mobile phones that come under this exchange;
	}

	@Override public boolean equals(Object other){
		assert(other instanceof Exchange);
		Exchange c=(Exchange)other;
		return (this.number==c.number); //the two exhanges are equal if their unique identifiers i.e. the numbers characteristic of them are the same
	}


}
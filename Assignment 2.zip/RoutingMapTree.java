	public class RoutingMapTree{

		private Exchange root;//the root node of the tree
		private MobilePhoneSet switched_on_phones;//has the pointer to all the switched on phones present in the RoutingMapTree data structure 

		public RoutingMapTree() {

			root=new Exchange(0);//this forms the root of the RoutingMapTree data structure
			switched_on_phones=new MobilePhoneSet();
		}
		
		public RoutingMapTree(Exchange e){
			root=e;
		}

		/*given a particular exchange a determines whether it is in the tree or not*/
		public boolean containsNode(Exchange a){
			//calls a private recursive function that finds out whether the node is contained in the tree or not
			return containsNode(this.root,a);
		}

		private Exchange NodeInTree(Exchange root,Exchange a){		 
		//assuming that a node equal to the node a is present in the tree we return the pointer to the original node present in the tree															
			boolean flag=false;
			if(root.numChildren()==0){
				if(root.equals(a)==true){// replacing a in-place of the root in the tree. Pending : the parent of b will still be pointing to the earlier node.correct that as well
					return root;
				}
			}
			else{//create a getIndex function for finding the position of the root in its parent's node
				flag=root.equals(a);
				if(flag==true){
					return root;
				}
				else{
					for(int i=0;i<root.numChildren();i++){
						flag=containsNode(root.child(i),a);
						if(flag==true){
							return NodeInTree(root.child(i),a);
						}
					}
				}
			}
			return null;//this is unreachable
		}

		private boolean containsNode(Exchange root,Exchange a){		//tells whether the tree contains the given Exchange node or not and if it does exchanges that 
			boolean flag=false;										//position with a node passed as a parameter
			if(root.numChildren()==0){
				if(root.equals(a)==true){// replacing a in-place of the root in the tree. Pending : the parent of b will still be pointing to the earlier node.correct that as well
					
					return true;
				}
				else{
					return false;
				}
			}
			else{//create a getIndex function for finding the position of the root in its parent's node
				flag=root.equals(a);
				if(flag==true){
					
					return flag;
				}
				else{
					for(int i=0;i<root.numChildren();i++){
						flag=containsNode(root.child(i),a);
						if(flag==true){
							
							return flag;
						}
					}
				}
			}
			return flag;
		}


		public void switchOn(MobilePhone a,Exchange b){
			a.switchOn();
			if(containsNode(b)){
			b.m_set.mobile_set.Insert(a);
			switched_on_phones.mobile_set.Insert(a);//inserting into the RoutingMapTree MobilePhoneSet
		}
	}

		public void switchOff(MobilePhone a){
			switchOff(a,root);// a private function that is used to switch off the phones
	}

	private void switchOff(MobilePhone a,Exchange root){
		if(root.m_set.mobile_set.IsMember(a)){
			if(root.numChildren()==0){//checking if the current node is an external node or not
				MobilePhone real_phone;
				real_phone=root.m_set.mobile_set.Mset.getCopyInside(a);//get the real copy from inside the linked list
				real_phone.switchOff();//switch it off
				//root.m_set.mobile_set.Delete(real_phone);
				//System.out.println("the phone number's "+real_phone.number+" status is "+real_phone.status);
				return;
			}
			else{
				MobilePhone real_phone;
				real_phone=root.m_set.mobile_set.Mset.getCopyInside(a);
				real_phone.switchOff();
				//root.m_set.mobile_set.Delete(real_phone);
				for(int i=0;i<root.numChildren();i++){
					if(root.child(i).m_set.mobile_set.IsMember(a)){//check for the node child which has the mobile phone as its member
						switchOff(a,root.child(i));//switch it off there as well
						return;
					}
				}
			}
		}
	}


	public Exchange findPhone(MobilePhone m){
		return m.location();//return the pointer stored in the location variable 
	}

	public Exchange lowestRouter(Exchange a,Exchange b){  // all level i exchanges are at the same height
		Exchange c=a;
		Exchange d=b;
		while(!c.equals(d)){ //till the time c is not equal to d(i.e. the exchanges they are pointing to have the same identifier )
			c=c.parent();  // make c point to its parent
			d=d.parent();  //make d point to its parent
		}
		return c;  //loop breaks when both start pointing to the exchanges with same identifiers.
	}



	public ExchangeList routeCall(MobilePhone a,MobilePhone b){
		Exchange c=findPhone(a);
		Exchange d=findPhone(b);
		ExchangeList list_of_a=new ExchangeList();
		ExchangeList list_of_b=new ExchangeList();
		//System.out.println("number of exchange 1 is "+c.number+" and that of exchange 2 is "+d.number);
		//int it=0;//keeps track of the number of iterations
		while(!c.equals(d)){//inserting in their respective lists the pointers to all the exchanges from one base level exchange to another
			list_of_a.ch.insertAtEnd(c);
			list_of_b.ch.insertAtEnd(d);
			c=c.parent();
			d=d.parent();
			//System.out.println("this is iteration number "+it);
			//it++;
		}
		list_of_a.ch.insertAtEnd(c);//inserting the node common to both the routes i.e. the lowestRouter into the list_of_a
		for(int i=(list_of_b.ch.getSize()-1);i>=0;i--){
			list_of_a.ch.insertAtEnd(list_of_b.ch.get(i));//starting from the level 0 router which is present at the end of the list, inserting all the nodes into the list_of_a  
		}
		return list_of_a; //this has the required sequence
	}



	public void movePhone(MobilePhone a,Exchange b){
	    try{
	    if(!root.m_set.mobile_set.IsMember(a)) throw new Exception("No mobile phone with identifier "+Integer.toString(a.number)+ " found in the network");     
		MobilePhone real_phone=root.m_set.mobile_set.Mset.getCopyInside(a);//accesing the pointer to the phone with the same identifier present inside the linked list
		if(!containsNode(b)) throw new Exception("No exchange with identifier "+Integer.toString(b.number)+ " found in the network");
		Exchange final_real_exchange=NodeInTree(root,b);
		Exchange initial_real_exchange=findPhone(real_phone);

		while(initial_real_exchange.parent()!=null){//delelting the phone from all the exchanges right upto the root
			initial_real_exchange.m_set.mobile_set.Delete(real_phone);
			initial_real_exchange=initial_real_exchange.parent();
		}
		real_phone.setLocation(final_real_exchange);
		while(final_real_exchange.parent()!=null){//inserting the phone inside all exchanges right upto the root
			final_real_exchange.m_set.mobile_set.Insert(real_phone);
			final_real_exchange=final_real_exchange.parent();
			
		}
		//real_phone.setLocation(final_real_exchange);
		//System.out.println("The identifier of the final location is "+real_phone.base.number);
		return;
	    }
	    catch(Exception e){
	        System.out.println(e.getMessage());
	    }
	}



		public String performAction(String actionMessage) {
			int i=0;

			while(!(actionMessage.substring(i,i+1).equals(" "))){
				i++;
			}

			String command=actionMessage.substring(0,i);//the string command contains the text part of the input command

			if(command.equals("addExchange")){//handling the "addExchange" command
				int j=1;
				while(!(actionMessage.substring(i+j,i+j+1).equals(" ")))j++;
				int parent_exchange_identifier=Integer.parseInt(actionMessage.substring(i+1,i+j));
				int child_exchange_identifier=Integer.parseInt(actionMessage.substring(i+j+1,actionMessage.length()));
				Exchange a_temp=new Exchange(parent_exchange_identifier);
				try{
				if(containsNode(a_temp)){//checking if the parent exchange is present in the routing map tree
					Exchange real_exchange=NodeInTree(root,a_temp);
					Exchange b=new Exchange(child_exchange_identifier);
					b.setParent(real_exchange);
					real_exchange.addChild(b);//adding a new child to the parent if it is present in the routing map tree
				}
				else{
					throw new Exception();//throws an excpetion if no such element as the parent a is present in the tree.
				}
			}
			catch(Exception e){
				System.out.println("Exception-Exchange with identifier "+parent_exchange_identifier+" couldn't be found.");
			}
			return "";
			}

			else if(command.equals("switchOnMobile")){
				
				int j=1;
				while(!(actionMessage.substring(i+j,i+j+1).equals(" ")))j++;
				int mobile_identifier=Integer.parseInt(actionMessage.substring(i+1,i+j));
				int parent_exchange_identifier=Integer.parseInt(actionMessage.substring(i+j+1,actionMessage.length()));
				Exchange a_temp=new Exchange(parent_exchange_identifier);
				try{
				if(containsNode(a_temp)){
					Exchange real_exchange=NodeInTree(root,a_temp);
					MobilePhone phone_temp=new MobilePhone(mobile_identifier);
					if(real_exchange.m_set.mobile_set.IsMember(phone_temp)){//checking if the phone is already the part of the exchange
						MobilePhone real_phone=a_temp.m_set.mobile_set.Mset.getCopyInside(phone_temp);
						real_phone.switchOn();
						//switched_on_phones.mobile_set.Insert(real_phone);//inserting a pointer to the real phone in the switched_on_phones set
					}
					else{//if the phone is already not present in the exchange just create a new phone and put it in
						phone_temp.switchOn();
						phone_temp.setLocation(real_exchange);//function for setting the location of the mobile phone object
						real_exchange.m_set.mobile_set.Insert(phone_temp);
						//switched_on_phones.mobile_set.Insert(phone_temp);//inserting a pointer to the phone in the switched_on_phones set
						while(real_exchange.parent()!=null){
							real_exchange=real_exchange.parent();
							real_exchange.m_set.mobile_set.Insert(phone_temp);
						}

					}
				}
				else{
					throw new Exception();
				}
			}
			catch(Exception e){
				System.out.println("Exception-Exchange with identifier "+parent_exchange_identifier+" couldn't be found.");
			}
			return "";
			}

			else if(command.equals("switchOffMobile")){
				//code
				int mobile_phone_identifier=Integer.parseInt(actionMessage.substring(i+1,actionMessage.length()));
				MobilePhone temp_phone=new MobilePhone(mobile_phone_identifier);
				try{
				if(root.m_set.mobile_set.IsMember(temp_phone)){
					switchOff(temp_phone);
				}
				else{
					throw new Exception();
				}
			}
			catch(Exception e){
				System.out.println("Exception-MobilePhone with identifier "+mobile_phone_identifier+" does not exist.");
			}
			return "";
			}

			else if(command.equals("queryNthChild")){
				int j=1;
				while(!(actionMessage.substring(i+j,i+j+1).equals(" ")))j++;
				int exchange_identifier=Integer.parseInt(actionMessage.substring(i+1,i+j));
				int child_number=Integer.parseInt(actionMessage.substring(i+j+1,actionMessage.length()));
				Exchange identifier_temp=new Exchange(exchange_identifier);
				try{
				if(containsNode(identifier_temp)){
						Exchange real_exchange=NodeInTree(root,identifier_temp);
						if(real_exchange==null)throw new Exception();
						 
						String str="queryNthChild "+actionMessage.substring(i+1,i+j)+" "+actionMessage.substring(i+j+1,actionMessage.length())+": "+Integer.toString(real_exchange.child(child_number).number);
						
						return str;
				}
				else{
					throw new Exception();
				}
			}
			catch(Exception e){
				System.out.println("Exception-Exchange does not exist.");
			}
			}

			else if(command.equals("queryMobilePhoneSet")){
				int exchange_identifier=Integer.parseInt(actionMessage.substring(i+1,actionMessage.length()));
				Exchange identifier_temp=new Exchange(exchange_identifier);
				try{
				if(containsNode(identifier_temp)){
					Exchange real_exchange=NodeInTree(root,identifier_temp);
					MobilePhoneSet r_set=real_exchange.m_set;//the mobile phone set of the node
				
					String str="queryMobilePhoneSet "+Integer.toString(exchange_identifier)+": ";
					for(MobilePhone ph:r_set.mobile_set.Mset){//for all the mobile phones in the set Mset
							

							if(ph.status)str=str+Integer.toString(ph.number)+", "; 
					}
					
					
				
					return str.substring(0,str.length()-2);
				}
				else{
					throw new Exception();
				}
			}
			catch(Exception e){
				
				String str="Exception-exchange with identifier "+Integer.toString(exchange_identifier)+" does not exist";
				return str;
			}
			}

			else if(command.equals("findPhone")){
				try{
				int mobile_phone_identifier=Integer.parseInt(actionMessage.substring(i+1,actionMessage.length()));
				MobilePhone temp_phone=new MobilePhone(mobile_phone_identifier);
				MobilePhone real_phone=root.m_set.mobile_set.Mset.getCopyInside(temp_phone);
				if(root.m_set.mobile_set.IsMember(real_phone)){
				Exchange loc_exchange=findPhone(real_phone);
				String str=Integer.toString(loc_exchange.number);
				str="queryFindPhone "+actionMessage.substring(i+1,actionMessage.length())+": "+str;
				
				return str;
			}
			else{
				throw new Exception();
			}
			}
				catch(Exception e){
					String str="queryFindPhone "+actionMessage.substring(i+1,actionMessage.length())+": "+"Error - No mobile phone with identifier "+actionMessage.substring(i+1,actionMessage.length())+" found in the network";
					return str;
				}
			}

			else if(command.equals("lowestRouter")){
				int j=1;
				while(!(actionMessage.substring(i+j,i+j+1).equals(" ")))j++;
				int exchange_1_identifier=Integer.parseInt(actionMessage.substring(i+1,i+j));
				int exchange_2_identifier=Integer.parseInt(actionMessage.substring(i+j+1,actionMessage.length()));
				Exchange temp1=new Exchange(exchange_1_identifier);
				Exchange temp2=new Exchange(exchange_2_identifier);
				Exchange real_1=NodeInTree(root,temp1);
				Exchange real_2=NodeInTree(root,temp2);
				Exchange lr=lowestRouter(real_1,real_2);
				String str="queryLowestRouter "+actionMessage.substring(i+1,i+j)+" "+actionMessage.substring(i+j+1,actionMessage.length())+": "+Integer.toString(lr.number);
		
				return str;
			}

			else if(command.equals("findCallPath")){
				try{
				int j=1;
				while(!(actionMessage.substring(i+j,i+j+1).equals(" ")))j++;
				int mobile_1_identifier=Integer.parseInt(actionMessage.substring(i+1,i+j));
				int mobile_2_identifier=Integer.parseInt(actionMessage.substring(i+j+1,actionMessage.length()));
				MobilePhone temp1=new MobilePhone(mobile_1_identifier);
				MobilePhone temp2=new MobilePhone(mobile_2_identifier);
				MobilePhone real_phone_1=root.m_set.mobile_set.Mset.getCopyInside(temp1);
				MobilePhone real_phone_2=root.m_set.mobile_set.Mset.getCopyInside(temp2);
				if(!real_phone_1.status){
					throw new Exception("queryFindCallPath 876 989: Error - Mobile phone with identifier "+Integer.toString(real_phone_1.number)+" is currently switched off");
				 }
				 else if(!real_phone_2.status){
				 	throw new Exception("queryFindCallPath 876 989: Error - Mobile phone with identifier "+Integer.toString(real_phone_2.number)+" is currently switched off");
				 }
				ExchangeList l=routeCall(real_phone_1,real_phone_2);
				String str="queryFindCallPath "+actionMessage.substring(i+1,i+j)+" "+actionMessage.substring(i+j+1,actionMessage.length())+": ";
				for(Exchange e:l.ch){
					str=str+Integer.toString(e.number)+", ";
				}
				str=str.substring(0,str.length()-2);
				
				return str;
			}
			catch(Exception e){
					
					return e.getMessage();
			}
			}

			else if(command.equals("movePhone")){
				int j=1;
				while(!(actionMessage.substring(i+j,i+j+1).equals(" ")))j++;
				int mobile_identifier=Integer.parseInt(actionMessage.substring(i+1,i+j));
				int exchange_identifier=Integer.parseInt(actionMessage.substring(i+j+1,actionMessage.length()));
				MobilePhone temp_phone=new MobilePhone(mobile_identifier);
				Exchange temp_exchange=new Exchange(exchange_identifier);
				movePhone(temp_phone,temp_exchange);
				return "";
			}
			return "";

		}
	}

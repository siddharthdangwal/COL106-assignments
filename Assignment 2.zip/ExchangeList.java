import java.util.*;
 class ExchangeList{
	public LinkedList<Exchange> ch;
	public ExchangeList(){
		ch=new LinkedList<Exchange>();
	}
}
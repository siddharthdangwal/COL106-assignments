 class MobilePhoneSet{
	public Myset<MobilePhone> mobile_set;
	public MobilePhoneSet(){
		mobile_set=new Myset<MobilePhone>();
	}
}
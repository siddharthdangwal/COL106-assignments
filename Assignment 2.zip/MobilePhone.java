import java.util.*;
 class MobilePhone{
	int number;  //the field element of the class
	boolean status;//this defines the switched on/switched off state of the mobile phone. true= switched on and false=switched off
	Exchange base;//the base to which the mobile phone is connected

	public MobilePhone(int number){
		this.number=number;
		this.status=true;//originally sqitched on
	}
	public Boolean status(){
		return this.status;
	}
	public void switchOn(){
		status=true;
	}
	public void switchOff(){
		status=false;
	}
	public Exchange location(){
		//code
		return this.base;
	}
	public void setLocation(Exchange location){
		this.base=location;
	}
	@Override public boolean equals(Object other){
		assert (other instanceof MobilePhone);
		MobilePhone c=(MobilePhone)other;
		return this.number==c.number;  //the two mobile phones are equal if their numbers are the same
	}


}